<template>
    <el-container class="container">
           <el-aside class="aside" :class={activeclass:isCollapse} >
               <el-col :span="6">
               <img src="../../assets/images/logo.png" class="logo"  alt="">
            </el-col>
            <!-- <el-col :span="18"  v-show="!isCollapse"> -->
                <div style="overflow:hidden;wifth:200px;">
                <div class="toptitle grid-content bg-purple" :class="!isCollapse?'moveout':'movein'" >{{!isCollapse?'创客联盟管理系统':''}}</div>
                </div>
            <!-- </el-col> -->
                <el-col :span="24">

                    <el-menu
                      
                        @open="handleOpen" @close="handleClose" :collapse="isCollapse"     
                            :collapse-transition="true"
                            show-timeout="600"
                            class="el-menu-vertical-demo line"
                            router
                          
                            background-color="#545c64"
                            text-color="#fff"
                            :unique-opened='false'
                            active-text-color="#ffd04b">
                       

      <el-submenu :index="level1.text" v-for="level1 in lefttar" :key="level1.id">
            <template slot="title">
              <i class="el-icon-menu"></i>
              <span slot="title">{{level1.text}}</span>
            </template>
            <el-menu-item v-for="level2 in level1.children" :key="level2.id" :index="level2.menuUrl" >{{level2.text}}</el-menu-item>
            
          </el-submenu>



                    </el-menu>
                </el-col>
            </el-aside>
            <el-container>
        <el-header class="header">
             <!-- <el-col :span="1">
               <img src="../../assets/images/logo.png" class="logo"  alt="">
            </el-col>
            <el-col :span="3" v-show="!isCollapse">
                <div class="toptitle grid-content bg-purple" >创客联盟管理系统</div>
            </el-col> -->
             <el-col :span="2">
               <img src="../../assets/images/sort.png" @click="hangleaside" class="sort" alt="">
            </el-col>
            
            <el-col :offset='16' :span="2">
                <div class="grid-content bg-purple-light"><a class="out" @click.prevent='logout'>退出</a></div>
            </el-col>
        </el-header>
       
         
            <el-main class="main">
                <router-view></router-view>
            </el-main>
        </el-container>
    </el-container>
</template>
<script>
    export default {
        data() {
            return {
                defaultActive: '/home/index',
                lefttar: [],
                isCollapse:false
            }
        },
        created () {
            this.getUserRoot()
        },
        methods: {
            /**
             * 获取用户权限
             * @return {[type]} [description]
             */
            getUserRoot() {
                let token = localStorage.getItem('ken')
                this.$http.post('ws_api/power/seltrue.do').then(res => {
                    console.log(res)
                    this.lefttar = res.data.info
                })
            },
            hangleaside(){
                this.isCollapse = !this.isCollapse

            },
            handleOpen (key, keyPath) {
                console.log(key, keyPath)
            },
            handleClose (key, keyPath) {
                console.log(key, keyPath)
            },
            logout () {
                this.$confirm('确定要退出吗?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    window.localStorage.removeItem('token')
                this.$router.push({

                    'name': 'login'
                })
                this.$message({
                    type: 'success',
                    message: '退出成功!'
                })
            }). catch(() => {}
            )}
        }
    }
</script>
<style scoped>
    .container {
        height: 100%;
    }
    .toptitle{
        font-size:18px;
        color:#fff;
        margin-top:10px;
        /* transition: all 400ms; */
        animation: mymove 400ms ;
    }
    .movein {
        animation: movein 400ms ;
    }
    .moveout {
        animation: moveout 400ms ;
    }

    .header {
        background-color: #303133;
        line-height: 50px;
        height: 50px !important;
    }

    .aside {
        background-color: #545c64;
        transition: all 300ms;
        overflow: hidden;
    width:240px !important ;
    box-sizing: border-box;
    }

    .aside .aside-menu {
        height: 100%;
    }

    .main {
        background-color: #E9EEF3;
        height: 100% !important;
    }

    .indexpage {
        padding-left: 60px !important;
    }

    .bigtitle {
        font-size: 20px;
        color: #333;
    }
    .out {
    color:#fff;
    font-size: 18px;

    }
    .el-menu-item.is-active{
            color: #409EFF !important;
    }
    .sort {
        width: 30px;
        height: 20px;
        margin-top:15px;
        margin-left:10px;
    }
    .activeclass {
        transition: all 300ms;
        width:54px !important;
    }
    .logo{
        width: 50px;
        height: 50px;
       
    }
    .line {
        border-right: none;
    }
@-webkit-keyframes moveout {
    0% {width: 240px;}
    50% {width: 120px;}
    100% {widows: 0;}
}
@-webkit-keyframes movein {
    0% {width: 0;}
    50% {width: 120px;}
    100% {widows: 240px;}
}
</style>
